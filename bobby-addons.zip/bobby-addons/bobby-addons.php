<?php
/**
 * Plugin Name: Bobby Addons
 * Description: Simple hello world widgets for Elementor.
 * Version:     1.0.0
 * Author:      Bobby Nicholson
 * Author URI:  https://developers.elementor.com/
 * Text Domain: bobby-addons
 */

function register_hello_bobby_widget( $widgets_manager ) {

	require_once( __DIR__ . '/widgets/hello-bobby.php' );
	// require_once( __DIR__ . '/widgets/hello-world-widget-2.php' );

	$widgets_manager->register( new \Elementor_Hello_Bobby_Widget() );
	// $widgets_manager->register( new \Elementor_Hello_World_Widget_2() );

}
add_action( 'elementor/widgets/register', 'register_hello_bobby_widget' );